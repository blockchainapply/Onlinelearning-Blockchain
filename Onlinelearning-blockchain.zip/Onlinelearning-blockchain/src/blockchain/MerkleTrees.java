package blockchain;

import java.util.ArrayList;
import java.util.List;

public class MerkleTrees {

	List<String> CourseList;// 需要存储的课程简介构成的列表
	String root;// 以哈希值形式呈现的默克尔树的根
	int index;// 默克尔树的序号

	/**
	 * 初始化默克尔树
	 */
	public MerkleTrees(List<String> CourseList, int index) {
		this.CourseList = CourseList;
		root = "";
		this.index = index;
	}

	/**
	 * 迭代函数
	 */
	private List<String> getNewCourseList(List<String> tempTxList) {

		List<String> newTxList = new ArrayList<String>();
		int index = 0;
		while (index < tempTxList.size()) {
			// 左子树赋值
			String left = tempTxList.get(index);
			index++;
			// 右字数赋值
			String right = "";
			if (index != tempTxList.size()) {
				right = tempTxList.get(index);
			}
			// 左右字数合并取哈希值
			String sha2HexValue = getShavalue.applySha256(left + right);
			newTxList.add(sha2HexValue);
			index++;

		}

		return newTxList;
	}

	/**
	 * 迭代构造默克尔树
	 */
	public void merkle_tree() {

		List<String> tempCourseList = new ArrayList<String>();

		for (int i = 0; i < this.CourseList.size(); i++) {
			tempCourseList.add(this.CourseList.get(i));
		}

		List<String> newCourseList = getNewCourseList(tempCourseList);

		while (newCourseList.size() != 1) {
			newCourseList = getNewCourseList(newCourseList);
		} // 迭代合并直到列表中值得数量为1

		this.root = newCourseList.get(0);// 将哈希值赋值给树根
	}

	public String getRoot() {
		return this.root;
	}

}